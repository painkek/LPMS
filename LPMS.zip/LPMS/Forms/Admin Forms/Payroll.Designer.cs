﻿namespace LPMS.Forms.Admin_Forms
{
    partial class Payroll
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.customButton1 = new LPMS.Class.CustomButton();
            this.textBoxCustom6 = new TextBoxCustom();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxCustom4 = new TextBoxCustom();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxCustom5 = new TextBoxCustom();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxCustom3 = new TextBoxCustom();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxCustom2 = new TextBoxCustom();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxCustom1 = new TextBoxCustom();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.Controls.Add(this.textBoxCustom6);
            this.panel1.Controls.Add(this.textBoxCustom4);
            this.panel1.Controls.Add(this.textBoxCustom5);
            this.panel1.Controls.Add(this.textBoxCustom3);
            this.panel1.Controls.Add(this.textBoxCustom2);
            this.panel1.Controls.Add(this.customButton1);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.textBoxCustom1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(178, 27);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(522, 583);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(110, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name:";
            // 
            // customButton1
            // 
            this.customButton1.BackColor = System.Drawing.Color.Orange;
            this.customButton1.FlatAppearance.BorderSize = 0;
            this.customButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.customButton1.Font = new System.Drawing.Font("Consolas", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customButton1.ForeColor = System.Drawing.Color.Black;
            this.customButton1.Location = new System.Drawing.Point(226, 510);
            this.customButton1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.customButton1.Name = "customButton1";
            this.customButton1.Size = new System.Drawing.Size(87, 37);
            this.customButton1.TabIndex = 13;
            this.customButton1.Text = "Submit";
            this.customButton1.UseVisualStyleBackColor = false;
            // 
            // textBoxCustom6
            // 
            this.textBoxCustom6.BackColor = System.Drawing.Color.Gainsboro;
            this.textBoxCustom6.Location = new System.Drawing.Point(171, 472);
            this.textBoxCustom6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxCustom6.Multiline = true;
            this.textBoxCustom6.Name = "textBoxCustom6";
            this.textBoxCustom6.Size = new System.Drawing.Size(191, 30);
            this.textBoxCustom6.TabIndex = 18;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(203, 450);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(128, 18);
            this.label7.TabIndex = 11;
            this.label7.Text = "TOTAL DEDUCTION";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // textBoxCustom4
            // 
            this.textBoxCustom4.BackColor = System.Drawing.Color.Gainsboro;
            this.textBoxCustom4.Location = new System.Drawing.Point(171, 395);
            this.textBoxCustom4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxCustom4.Multiline = true;
            this.textBoxCustom4.Name = "textBoxCustom4";
            this.textBoxCustom4.Size = new System.Drawing.Size(191, 30);
            this.textBoxCustom4.TabIndex = 17;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(223, 362);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 18);
            this.label6.TabIndex = 9;
            this.label6.Text = "PHILHEALTH";
            // 
            // textBoxCustom5
            // 
            this.textBoxCustom5.BackColor = System.Drawing.Color.Gainsboro;
            this.textBoxCustom5.Location = new System.Drawing.Point(171, 308);
            this.textBoxCustom5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxCustom5.Multiline = true;
            this.textBoxCustom5.Name = "textBoxCustom5";
            this.textBoxCustom5.Size = new System.Drawing.Size(191, 30);
            this.textBoxCustom5.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(225, 274);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 18);
            this.label5.TabIndex = 7;
            this.label5.Text = "PAG-IBIG";
            // 
            // textBoxCustom3
            // 
            this.textBoxCustom3.BackColor = System.Drawing.Color.Gainsboro;
            this.textBoxCustom3.Location = new System.Drawing.Point(171, 226);
            this.textBoxCustom3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxCustom3.Multiline = true;
            this.textBoxCustom3.Name = "textBoxCustom3";
            this.textBoxCustom3.Size = new System.Drawing.Size(191, 30);
            this.textBoxCustom3.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(250, 194);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 18);
            this.label4.TabIndex = 5;
            this.label4.Text = "SSS";
            // 
            // textBoxCustom2
            // 
            this.textBoxCustom2.BackColor = System.Drawing.Color.Gainsboro;
            this.textBoxCustom2.Location = new System.Drawing.Point(171, 144);
            this.textBoxCustom2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxCustom2.Multiline = true;
            this.textBoxCustom2.Name = "textBoxCustom2";
            this.textBoxCustom2.Size = new System.Drawing.Size(191, 30);
            this.textBoxCustom2.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(225, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 18);
            this.label3.TabIndex = 3;
            this.label3.Text = "Gross Pay:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(224, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 23);
            this.label2.TabIndex = 2;
            this.label2.Text = "Payroll";
            // 
            // textBoxCustom1
            // 
            this.textBoxCustom1.BackColor = System.Drawing.Color.Gainsboro;
            this.textBoxCustom1.Location = new System.Drawing.Point(171, 25);
            this.textBoxCustom1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxCustom1.Multiline = true;
            this.textBoxCustom1.Name = "textBoxCustom1";
            this.textBoxCustom1.Size = new System.Drawing.Size(191, 30);
            this.textBoxCustom1.TabIndex = 1;
            this.textBoxCustom1.TextChanged += new System.EventHandler(this.textBoxCustom1_TextChanged);
            // 
            // Payroll
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(245)))), ((int)(((byte)(244)))));
            this.ClientSize = new System.Drawing.Size(895, 644);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Payroll";
            this.Text = "Payroll";
            this.Load += new System.EventHandler(this.Payroll_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private TextBoxCustom textBoxCustom6;
        private TextBoxCustom textBoxCustom4;
        private TextBoxCustom textBoxCustom5;
        private TextBoxCustom textBoxCustom3;
        private TextBoxCustom textBoxCustom2;
        private Class.CustomButton customButton1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private TextBoxCustom textBoxCustom1;
        private System.Windows.Forms.Label label1;
    }
}