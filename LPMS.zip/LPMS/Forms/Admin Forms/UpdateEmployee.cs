﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LPMS.Forms.Admin_Forms
{
    public partial class UpdateEmployees : Form
    {
        SqlConnection con = new SqlConnection("Data Source=LAPTOP-PVPF344M\\SQLEXPRESS01;Initial Catalog=LPMS;Integrated Security=True");
        SqlCommand cmd = new SqlCommand();

        public UpdateEmployees()
        {
            InitializeComponent();
        }

        private void AddEmployees_Load(object sender, EventArgs e)
        {

        }

        public void btnAddEmployee_Click(object sender, EventArgs e)
        {
            
        }

        private void cbShowpwEmp_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
