﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace LPMS.Forms.Admin_Forms
{

    public partial class ManageEmployees : Form
    {
        SqlConnection con = new SqlConnection("Data Source=LAPTOP-PVPF344M\\SQLEXPRESS01;Initial Catalog=LPMS;Integrated Security=True");
        SqlCommand cmd = new SqlCommand();
        public ManageEmployees()
        {
            InitializeComponent();
        }

        private void ManageEmployees_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'lPMSDataSet.tbl_addEmp' table. You can move, or remove it, as needed.
            this.tbl_addEmpTableAdapter.Fill(this.lPMSDataSet.tbl_addEmp);

        }
        public void refreshData()
        {
            //refresh
            string query = "SELECT * FROM tbl_addemp";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "Employee info");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Employee info";
            dataGridView1.DataSource = dataGridView1.DataSource;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.Rows.Count > 1) 
                {
                    if (dataGridView1.CurrentRow.Index == dataGridView1.Rows.Count - 1)
                    {
                        MessageBox.Show("Please Select Data!");
                    }
                    else
                    {
                        if (MessageBox.Show("Do you want to delete this data?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                        {
                            string del = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                            con.Open();
                            cmd = new SqlCommand("DELETE FROM tbl_addemp WHERE ID = '" + del + "'", con);
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Data Deleted");
                            refreshData();
                            con.Close();
                        }
                    } 
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void btnEdit_Click(object sender, EventArgs e)
        {
            UpdateEmployees updateEmp = new UpdateEmployees();
            updateEmp.txtEmpID.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            updateEmp.txtFirst_Name.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            updateEmp.txtLast_Name.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            updateEmp.txt_Address.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            updateEmp.txt_Contact.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            updateEmp.txt_Position.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            updateEmp.txt_Gender.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            updateEmp.txtUsernameEMP.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            updateEmp.txtPasswordEMP.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
            updateEmp.ShowDialog();

        }
    }
}
