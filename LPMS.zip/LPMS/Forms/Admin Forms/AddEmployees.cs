﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LPMS.Forms.Admin_Forms
{
    public partial class AddEmployees : Form
    {
        SqlConnection con = new SqlConnection("Data Source=LAPTOP-PVPF344M\\SQLEXPRESS01;Initial Catalog=LPMS;Integrated Security=True");
        SqlCommand cmd = new SqlCommand();

        public AddEmployees()
        {
            InitializeComponent();
        }

        private void AddEmployees_Load(object sender, EventArgs e)
        {

        }

        private void btnAddEmployee_Click(object sender, EventArgs e)
        {
            if (txtEmployeeID.Text == "")
            {

            }
            con.Open();
            cmd = new SqlCommand("INSERT INTO tbl_addEmp(ID, Firstname, Lastname, Address, Contact, Position, Gender, Username, Password) VALUES('" + txtEmployeeID.Text + "', '" + txtFirstName.Text + "', '" + txtLastName.Text + "', '" + txtAddress.Text + "', '" + txtContact.Text + "', '" + txtPosition.Text + "', '" + txtGender.Text + "', '" + txtUsernameEMP.Text + "', '" + txtPasswordEMP.Text + "'  )", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Employee Added");
            con.Close();
        }

        private void cbShowpwEmp_CheckedChanged(object sender, EventArgs e)
        {
            if(cbShowpwEmp.Checked)
            {
                txtPasswordEMP.UseSystemPasswordChar = false;
            }
            else
            {
                txtPasswordEMP.UseSystemPasswordChar = true;
            }
        }
    }
}
